package listy;
import java.io.*;
import java.util.*;
import java.lang.*;


class Lista{
	public static void main (String [] Args)
	{
		List lista = new ArrayList();
		lista.add(2);
		lista.add("XXXDDD");
		System.out.println(lista);
		lista.remove("XXXDDD");
		System.out.println(lista);
		
	}
	
}
