package listy;
import java.io.*;

class Tablica {
	public static void main (String []Args){
		int[] tablica = new int[23];
		System.out.println(tablica);
		for (int i = 0; i< 23; i++) {
			tablica[i] = i+4;
		
		System.out.println(tablica);
		
		/*int[] tablica = new int[10];

		for (int i = 0; i < 10; i++)
			tablica[i] = i + 1;

		int zmienna = tablica[3];

		for (int i = 0; i < 10; i++)
			System.out.println("Kolejna kom�rka to: " + tablica[i]);
		*/
		}
	}
}
